extends Control

@onready var base = $Base
@onready var knob = $Knob

var dragging = false
var direction = Vector2.ZERO
var radius = 100

var center = Vector2.ZERO  # store original center

func _ready():
	center = knob.position  # use your already set center

func _input(event):
	if event is InputEventScreenTouch:
		if event.pressed:
			dragging = true
		else:
			dragging = false
			direction = Vector2.ZERO
			knob.position = center  # return to original center

	if event is InputEventScreenDrag and dragging:
		var offset = event.position - center

		if offset.length() > radius:
			offset = offset.normalized() * radius

		knob.position = center + offset
		direction = offset / radius
